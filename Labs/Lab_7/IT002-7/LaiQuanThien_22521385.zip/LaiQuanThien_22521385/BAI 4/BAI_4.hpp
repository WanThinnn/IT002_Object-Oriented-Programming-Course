#ifndef BAI_4_hpp
#define BAI_4_hpp

#include <stdio.h>
#include <cmath>
#include <iostream>
#include "DIEM_CLASS.h"
#include "DIEM_CODE.h"
#include "ELIP_CLASS.h"
#include "ELIP_CODE.h"
#include "HTRON_CLASS.h"
#include "HTRON_CODE.h"


#endif /* BAI_4_hpp */
