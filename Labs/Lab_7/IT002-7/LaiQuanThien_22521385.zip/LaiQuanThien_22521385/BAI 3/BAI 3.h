
#ifndef BAI_3_h
#define BAI_3_h
#include <iostream>
#include <string>
#include "NGUOI_CLASS.h"
#include "NGUOI_CODE.h"
#include "SINHVIEN_CLASS.h"
#include "SINHVIEN_CODE.h"
#include "HOCSINH_CLASS.h"
#include "HOCSINH_CODE.h"
#include "CONGNHAN_CLASS.h"
#include "CONGNHAN_CODE.h"
#include "CASI_CLASS.h"
#include "CASI_CODE.h"
#include "NGHESI_CLASS.h"
#include "NGHESI_CODE.h"
#include "LIST_CLASS.h"
#include "LIST_CODE.h"
#endif /* BAI_2_h */
