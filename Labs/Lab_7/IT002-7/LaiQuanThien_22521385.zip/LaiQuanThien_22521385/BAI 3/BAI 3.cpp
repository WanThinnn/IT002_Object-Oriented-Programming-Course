#include "BAI 3.h"

int main()
{
    LIST List;
    cin >> List;
    cout << List;
}
