#ifndef BAI_5_hpp
#define BAI_5_hpp

#include <stdio.h>
#include <cmath>
#include <iostream>
#include "DIEM_CLASS.h"
#include "DIEM_CODE.h"
#include "HINHHOC_CLASS.h"
#include "HINHHOC_CODE.h"
#include "HCN_CLASS.h"
#include "HCN_CODE.h"
#include "HVUONG_CLASS.h"
#include "HVUONG_CODE.h"
#include "HBH_CLASS.h"
#include "HBH_CODE.h"
#include "HTHANG_CLASS.h"
#include "HTHANG_CODE.h"





#endif
