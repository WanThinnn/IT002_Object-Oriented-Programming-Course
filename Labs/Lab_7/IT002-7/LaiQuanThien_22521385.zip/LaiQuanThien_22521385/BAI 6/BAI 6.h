
#ifndef BAI_2_h
#define BAI_2_h
#include <random>
#include <iostream>
#include <string>
#include "GIASUC_CLASS.h"
#include "GIASUC_CODE.h"
#include "BO_CLASS.h"
#include "BO_CODE.h"
#include "CUU_CLASS.h"
#include "CUU_CODE.h"
#include "DE_CLASS.h"
#include "DE_CODE.h"
#include "LIST_CLASS.h"
#include "LIST_CODE.h"
#endif /* BAI_6_h */
