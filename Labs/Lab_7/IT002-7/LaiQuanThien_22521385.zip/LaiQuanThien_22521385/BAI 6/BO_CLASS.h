
#ifndef BO_CLASS
#define BO_CLASS


class BO : public GIASUC
{
    public:
        BO();
        ~BO();
};


#endif
