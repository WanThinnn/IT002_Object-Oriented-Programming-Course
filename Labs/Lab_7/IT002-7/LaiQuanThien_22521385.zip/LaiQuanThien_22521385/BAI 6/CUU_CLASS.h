#ifndef CUU_CLASS
#define CUU_CLASS

class CUU : public GIASUC
{
    public:
        CUU();
        ~CUU();
};

#endif
