#include "BAI 6.h"

int main()
{
    LIST List;
    cin >> List;
    cout << List;
    List.Amthanh_bi_bodoi();
}
