#ifndef DE_CLASS
#define DE_CLASS

class DE : public GIASUC
{
    public:
        DE();
        ~DE();
};

#endif
