#include "BAI 2.h"

int main()
{
    LIST List;
    cin >> List;
    cout << List;
}
